module.exports = {

  TITLE: 'Rmail',
  USER: 'seanlin0800@rmail.com'

};
